package com.example.ynapplication.fragment;

import com.example.ynapplication.R;
import com.example.ynapplication.common.BaseFragment;

public class HomeFragment extends BaseFragment {
    @Override
    public int getContentViewId() {
        return R.layout.fragment_home;
    }
}
