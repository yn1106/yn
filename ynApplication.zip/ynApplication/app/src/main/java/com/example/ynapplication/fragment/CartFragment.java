package com.example.ynapplication.fragment;

import com.example.ynapplication.R;
import com.example.ynapplication.common.BaseFragment;

public class CartFragment extends BaseFragment {
    @Override
    public int getContentViewId() {
        return R.layout.fragment_cart;
    }
}