package com.example.ynapplication.common;

public class Constants {
    public static final String BASE_URL="http://10.216.151.29:8080/MobileShop/";
}
